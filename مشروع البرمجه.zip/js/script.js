let btnDark = document.getElementById("btnDark");
let iocnMode=document.getElementById("iocnMode");
if (localStorage.getItem('background')=='dark'){
  document.body.classList.add("dark-mode");
}else if(localStorage.getItem('background')=='light'){
  document.body.classList.remove("dark-mode");

}
if (document.body.classList.contains("dark-mode")) {
  iocnMode.classList.remove("fa-sun");
  iocnMode.classList.add("fa-moon");
} else {
  iocnMode.classList.remove("fa-moon");
  iocnMode.classList.add("fa-sun");
}
btnDark.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
  iocnMode.style.transform='rotate(360deg)'
  if(document.body.classList.contains("dark-mode")){
    iocnMode.classList.remove("fa-sun");
    iocnMode.classList.add("fa-moon");
    localStorage.setItem('background','dark')
  }else{
    iocnMode.style.transform='rotate(0deg)'
    iocnMode.classList.remove("fa-moon");
    iocnMode.classList.add("fa-sun");
    localStorage.setItem('background', 'light')
  }
});
let goToTop=document.getElementsByClassName('goToTop')[0]
document.addEventListener('scroll',function(){
  if(scrollY >=400){
    goToTop.style.display='block'
  }else{
    goToTop.style.display='none'
  }
})
goToTop.addEventListener('click',function(){
  scrollTo({
    top:0,
    behavior:'smooth'
  })
})
// اضافة السنة 
let yearData=document.getElementById('data')
yearData.innerHTML=new Date().getFullYear()

// Slider functionality

let currentSlide = 0;
const slides = document.querySelectorAll(".slide");
const totalSlides = slides.length;
let sliderDots = document.querySelector(".slider-dots");

for (let i = 0; i < slides.length; i++) {
  let data = `<span class="dot" data-index="${i}"></span>`;
  sliderDots.innerHTML += data;
}
let dots = document.querySelectorAll(".dot");
function nextSlide() {
  currentSlide++;
  if (currentSlide >= totalSlides) {
    currentSlide = 0;
  }
  showSlide(currentSlide);
}
function prevSlide() {
  currentSlide--;
  if (currentSlide < 0) {
    currentSlide = totalSlides-1;
  }
  showSlide(currentSlide);
}
function showSlide(index) {
  currentSlide = index;
  removeActive();
  slides[index].classList.add("active");
  dots[index].classList.add("active");
}
function removeActive() {
  slides.forEach((slide) => {
    slide.classList.remove("active");
  });
  dots.forEach((dot) => {
    dot.classList.remove("active");
  });
}
for (let i = 0; i < dots.length; i++) {
  dots[i].addEventListener("click", function () {
    currentSlide = i;
    showSlide(currentSlide);
  });
}

// // Auto slide every 5 seconds
setInterval(nextSlide, 5000);

// // Filter courses by year
document.addEventListener("DOMContentLoaded", function () {
  const filterButtons = document.querySelectorAll(".filter-btn");
  const courseCards = document.querySelectorAll(".course-card");
  const specializationFilters = document.querySelectorAll(
    ".specialization-filter"
  );
  const specBtns = document.querySelectorAll(".spec-btn");

  let currentYear = "all";

  filterButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // Remove active class from all buttons
      filterButtons.forEach((btn) => btn.classList.remove("active"));
      // Add active class to clicked button
      this.classList.add("active");
      currentYear = this.getAttribute("data-year");
    });
  });
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute("href")).scrollIntoView({
      behavior: "smooth",
    });
  });
});

// Add animation to cards on scroll
const observerOptions = {
  threshold: 0.1,
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("animate");
    }
  });
}, observerOptions);

document
  .querySelectorAll(".news-card, .course-card, .faculty-card, .team-card")
  .forEach((card) => {
    observer.observe(card);
  });

// اختيار أزرار السنوات وبطاقات المواد وفلاتر التخصصات
const yearButtons = document.querySelectorAll(".filter-btn");
const courseCards = document.querySelectorAll(".course-card");
const specializationFilters = document.querySelector(".specialization-filter");
let currentYear = "all";

// عند الضغط على زر السنة
yearButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    // تفعيل الزر المختار
    yearButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentYear = btn.getAttribute("data-year");

    // إظهار المواد حسب السنة
    courseCards.forEach((card) => {
      if (card.getAttribute("data-year") === currentYear) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
    // إخفاء كل فلاتر التخصص
    specializationFilters.style.display = "none";
    // إذا السنة الثالثة أو الرابعة، أظهر فلاتر التخصص
    if (currentYear === "3" || currentYear === "4") {
      specializationFilters.setAttribute("data-year", `${currentYear}`);
      const filter = document.querySelector(
        `.specialization-filter[data-year="${currentYear}"]`
      );

      filter.style.display = "block";
      if (filter) {
        // إظهار كل المواد الخاصة بالسنة المختارة
        courseCards.forEach((card) => {
          if (
            card.getAttribute("data-year") === currentYear &&
            card.getAttribute("data-spec") === "tech"
          ) {
            card.style.display = "";
          } else {
            card.style.display = "none";
          }
        });
      }
    }
  });
});
// استدعاء الفلترة بعد الضغط على زر السنة
let filters = document.querySelectorAll(".spec-btn");
let cards = document.querySelectorAll(".course-card");
// فلترة التخصصات
filters.forEach((filter) => {
  filter.addEventListener("click", () => {
    filters.forEach((f) => f.classList.remove("active"));
    filter.classList.add("active");
    for (let i = 0; i < cards.length; i++) {
      if (
        filter.getAttribute("data-spec") == cards[i].getAttribute("data-spec")
      ) {
        cards[i].style.display = "block";
      } else {
        cards[i].style.display = "none";
      }
    }
  });
});
// تفعيل السنة الأولى افتراضياً عند تحميل الصفحة
window.addEventListener("DOMContentLoaded", () => {
  const defaultBtn =
    document.querySelector(".filter-btn.active") ||
    document.querySelector('.filter-btn[data-year="all"]');
  if (defaultBtn) defaultBtn.click();
});
let alrtbooks=document.getElementsByClassName('alrtbooks')[0]
function search(word){
  for(let i = 0; i < cards.length; i++){
    if(cards[i].querySelector("h3").textContent.toLowerCase().includes(word.toLowerCase())){
      cards[i].style.display = "block";
      alrtbooks.style.display='none'
    }else{
      cards[i].style.display = "none";
      alrtbooks.style.display='block'
    }
  }
}

let goals = document.getElementsByClassName("goals")[0];
let goalsContainer = document.getElementsByClassName("goals-container")[0];
let goalsList = document.getElementsByClassName("goals-list")[0];
let iconDowns = document.querySelectorAll(".containers .iconDown");

let containers = document.querySelectorAll(".containers");

let text = document.querySelectorAll(".text");

containers.forEach((container, index) => {
  container.addEventListener("click", () => {
    if (text[index].style.display === "block") {
      text[index].style.display = "none";
      iconDowns[index].classList.remove("active");
    } else {
      text[index].style.display = "block";
      iconDowns[index].classList.add("active");
    }
  });
});

//  استدعاء الطبقاة اللي هيظهر فيها الصورة 
let lr = document.getElementById("lr");
//  استدعاء الصوره بالادي 
let alrt = document.getElementById("prsonImg");
// استدعاء جميع الكارت اللي بيحمل الصورة  باستخدام id 
let prson = document.querySelectorAll(".us");
// استدعاء زي الخروج من الطبقة اللي هيظهر فيها الصورة 
let exitAlrt = document.getElementById("exitAlrt");

// عملت لوب علي جميع الكارتات 
prson.forEach((p) => {
  // عند الضغط علي الكارت 
  p.addEventListener("click", () => {
    // خليت الكرت يظهر 
    lr.style.display = "flex";
    // عملت متغير وحفظت فيه السورس اللي هو رابط الصورة 
    let img = p.querySelector("img");
    let imgSrc = img.getAttribute("src");
    // حطيط الرابط بتاع الصورة جوا الكارت اللي عملتوا 
    alrt.setAttribute("src", imgSrc);
  })
})
// هنا بقلوا اقفل الكارت اول ما يدوس علي اقون الغلق 
document.addEventListener("click", (e) => {
  if (e.target === exitAlrt || e.target === lr ) {
    lr.style.display = "none";
  }
});

let facultyCards=document.querySelectorAll('.faculty-card')
let alrtFaculty=document.getElementsByClassName('alrtFaculty')[0]
function searchFaculty(word){
  for(let i = 0; i < facultyCards.length; i++){
    if(facultyCards[i].querySelector("h3").textContent.toLowerCase().includes(word.toLowerCase())){
      facultyCards[i].style.display = "block";
      alrtFaculty.style.display='none'
    }else{
      facultyCards[i].style.display = "none";
      alrtFaculty.style.display='block'
    }
  }
}
